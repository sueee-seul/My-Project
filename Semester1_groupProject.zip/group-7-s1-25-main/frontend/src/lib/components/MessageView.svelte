<script>
  export let message;
</script>

<p>{message.message}</p>
