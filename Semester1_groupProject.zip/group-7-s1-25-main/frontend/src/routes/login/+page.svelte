<script>
    import Login from "../../lib/components/Login.svelte";
</script>

<Login />

<svelte:head>
    <title>BlogHub - Login</title>
</svelte:head>