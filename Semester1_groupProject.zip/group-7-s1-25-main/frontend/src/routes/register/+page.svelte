<script>
    import Register from "../../lib/components/Register.svelte";
</script>

<Register />

<svelte:head>
    <title>BlogHub - Register</title>
</svelte:head>